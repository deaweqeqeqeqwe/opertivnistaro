#ifndef NITI_HPP_INCLUDED
#define NITI_HPP_INCLUDED

#include <vector>

#include "suma_vektora.hpp"

using namespace std;

// v - vektor A čije elemente treba sumirati
// v - vektor B čije elemente treba sumirati
// povratna vrednost - suma korespondentnih elemenata vektora A i B, izračunata pozivanjem dve niti
vector<double> sumiraj(vector<double> a, vector<double> b) {
    // Implementirati ...
}

#endif // NITI_HPP_INCLUDED
