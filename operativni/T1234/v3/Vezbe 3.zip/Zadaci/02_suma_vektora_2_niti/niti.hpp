#ifndef NITI_HPP_INCLUDED
#define NITI_HPP_INCLUDED

#include <vector>

#include "suma_vektora.hpp"

using namespace std;

// v - vektor čije elemente treba sumirati
// povratna vrednost - suma svih elemenata vektora, izračunata pokretanjem 2 niti (svaka treba da obradi jednu polovinu elemenata)
double sumiraj(vector<double> v) {
    // Implementirati ...
}

#endif // NITI_HPP_INCLUDED
