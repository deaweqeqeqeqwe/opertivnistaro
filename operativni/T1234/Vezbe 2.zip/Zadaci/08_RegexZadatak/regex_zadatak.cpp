/*
    Uz zadatke ide fajl koji se zove ulaz.txt
    U njemu se nalaze bodovi studenata u formi:
    Ime,Prezime,V=70&P=30,Beleska
    Napraviti program koji na osnovu fajla sračuna prosek za V (vežbe) i prosek za 
    P(ispit). 
*/