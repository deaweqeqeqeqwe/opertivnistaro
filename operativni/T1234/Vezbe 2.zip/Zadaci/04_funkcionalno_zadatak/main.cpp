/*
    Napraviti funkciju koja sortira dati vektor int-ova koristeći
    za određivanje da li je neki element manji ili veći od drugog
    prosleđenu funkciju. Demonstrirati ovo kroz lambda izraz.

    Bonus zadaci:
    1. Implementirati ovo da radi sa bilo kojim tipom kroz
    šablone.
    2. Implementirati ovo kroz quicksort algoritam.
*/
